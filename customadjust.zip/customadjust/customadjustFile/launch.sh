#!/bin/bash
java -jar Adjust.jar
read -p "Press [Enter] to continue..."
